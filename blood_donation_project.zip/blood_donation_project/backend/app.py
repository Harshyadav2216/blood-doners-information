from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import sqlite3
import csv
import os

app = Flask(__name__)
CORS(app)

DATABASE = 'database.db'
EXPORT_FOLDER = 'exports'

# Ensure exports folder exists
os.makedirs(EXPORT_FOLDER, exist_ok=True)

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/donors', methods=['GET'])
def get_donors():
    conn = get_db_connection()
    donors = conn.execute('SELECT * FROM donors').fetchall()
    conn.close()
    return jsonify([dict(row) for row in donors])

@app.route('/donors', methods=['POST'])
def add_donor():
    new_donor = request.get_json()
    name = new_donor['name']
    blood_group = new_donor['blood_group']
    contact = new_donor['contact']
    location = new_donor['location']

    conn = get_db_connection()
    conn.execute('INSERT INTO donors (name, blood_group, contact, location) VALUES (?, ?, ?, ?)',
                 (name, blood_group, contact, location))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Donor added successfully'}), 201

@app.route('/donors/<int:donor_id>', methods=['DELETE'])
def delete_donor(donor_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM donors WHERE id = ?', (donor_id,))
    conn.commit()
    conn.close()

    if cursor.rowcount == 0:
        return jsonify({'message': 'Donor not found'}), 404

    return jsonify({'message': 'Donor deleted successfully'}), 200

@app.route('/export', methods=['GET'])
def export_to_csv():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM donors")
    rows = cursor.fetchall()

    file_path = os.path.join(EXPORT_FOLDER, 'donors.csv')

    with open(file_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([desc[0] for desc in cursor.description])  # headers
        writer.writerows(rows)

    conn.close()
    return send_file(file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
