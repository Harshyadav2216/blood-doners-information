// Confirm deletion
function confirmDelete() {
    return confirm("⚠ Are you sure you want to delete this donor?");
}

// Fancy Carousel Logic
let index = 0;
const items = document.querySelectorAll(".carousel-item");

function showSlide() {
    document.querySelector(".carousel-inner").style.transform = `translateX(-${index * 100}%)`;
}

function nextSlide() {
    index = (index + 1) % items.length;
    showSlide();
}

function prevSlide() {
    index = (index - 1 + items.length) % items.length;
    showSlide();
}

setInterval(nextSlide, 4000); // Auto-slide every 4 seconds
